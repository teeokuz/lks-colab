"""Last Known Seconds - gerador v2 no Google Colab grátis (1 GPU T4, ~12 GB de RAM).

Vai dentro do lote (.zip) e roda pelo notebook LKS_gerador.ipynb:
    python lks_colab.py <pasta_do_lote> <pasta_de_saida>

Etapas (cada uma num processo separado, para liberar a memória da GPU):
  1. FLUX.1-schnell (Apache 2.0, GGUF Q6 de city96) -> imagens-chave das cenas com "cands"
  2. FastWan 2.2 TI2V-5B (Apache 2.0) -> anima as imagens escolhidas ("picks")
  3. Real-ESRGAN general-x4v3 (BSD-3) -> amplia para a resolução final
A saída fica no Google Drive: se a sessão cair, rodar de novo continua de onde parou.
"""
import os, sys, json, glob, time, shutil, subprocess

IN, OUT = sys.argv[1], sys.argv[2]
os.environ['HF_HOME'] = '/content/hf'
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'expandable_segments:True'
os.environ['LKS_IN'], os.environ['LKS_OUT'] = IN, OUT
SHOTS = json.load(open(f'{IN}/shots.json', encoding='utf-8'))
CFG = json.load(open(f'{IN}/cfg.json', encoding='utf-8'))
for d in ('keyframes', 'clips', 'final'):
    os.makedirs(f'{OUT}/{d}', exist_ok=True)
T0 = time.time()


def log(*a):
    print(f'[{(time.time() - T0) / 60:5.1f} min]', *a, flush=True)


# Carrega um codificador de texto em bf16 direto na GPU; se a T4 recusar bf16, usa fp16.
TXT_LOADER = r'''
import torch
def load_txt(cls, path, sub):
    for dt in (torch.bfloat16, torch.float16):
        try:
            m = cls.from_pretrained(path, subfolder=sub, torch_dtype=dt, device_map={'': 0}).eval()
            with torch.no_grad():  # teste: a T4 roda este tipo de número e não gera NaN?
                y = m(torch.ones(1, 8, dtype=torch.long, device='cuda'))[0]
            assert torch.isfinite(y.float()).all(), 'NaN'
            print(sub, 'em', dt, flush=True)
            return m
        except Exception as e:
            m = None; torch.cuda.empty_cache()
            print('falhou em', dt, repr(e)[:200], flush=True)
    raise SystemExit('não carregou ' + sub)
'''

FLUX_ENC = TXT_LOADER + r'''
import os, sys, json
from transformers import CLIPTextModel, CLIPTokenizer, T5EncoderModel, T5TokenizerFast
M = sys.argv[1]
shots = [s for s in json.load(open(os.environ['LKS_IN'] + '/shots.json', encoding='utf-8')) if s.get('cands')]
os.makedirs('/content/femb', exist_ok=True)
tok1 = CLIPTokenizer.from_pretrained(M, subfolder='tokenizer')
tok2 = T5TokenizerFast.from_pretrained(M, subfolder='tokenizer_2')
clip = CLIPTextModel.from_pretrained(M, subfolder='text_encoder', torch_dtype=torch.float32).to('cuda').eval()
t5 = load_txt(T5EncoderModel, M, 'text_encoder_2')
with torch.no_grad():
    for s in shots:
        p = s['kf_prompt']
        ids = tok1([p], padding='max_length', max_length=77, truncation=True, return_tensors='pt').input_ids.to('cuda')
        pooled = clip(ids, output_hidden_states=False).pooler_output.float().cpu()
        ids2 = tok2([p], padding='max_length', max_length=256, truncation=True, return_tensors='pt').input_ids.to('cuda')
        pe = t5(ids2, output_hidden_states=False)[0].float().cpu()
        assert torch.isfinite(pe).all(), 'T5 gerou NaN'
        torch.save({'pe': pe, 'pooled': pooled}, f"/content/femb/{s['id']}.pt")
print('flux encode ok', len(shots), flush=True)
'''

FLUX = r'''
import os, sys, json, time, torch
from diffusers import FluxPipeline, FluxTransformer2DModel, GGUFQuantizationConfig
M, G = sys.argv[1], sys.argv[2]
OUT = os.environ['LKS_OUT']
cfg = json.load(open(os.environ['LKS_IN'] + '/cfg.json'))
shots = [s for s in json.load(open(os.environ['LKS_IN'] + '/shots.json', encoding='utf-8')) if s.get('cands')]
dt = torch.float16
tr = FluxTransformer2DModel.from_single_file(G, quantization_config=GGUFQuantizationConfig(compute_dtype=dt),
                                             torch_dtype=dt, config=M, subfolder='transformer')
pipe = FluxPipeline.from_pretrained(M, transformer=tr, text_encoder=None, text_encoder_2=None,
                                    tokenizer=None, tokenizer_2=None, torch_dtype=dt)
pipe.transformer.to('cuda'); pipe.vae.to('cuda', dtype=torch.float32)
for s in shots:
    kw, kh = s.get('kf_w', cfg['kf_w']), s.get('kf_h', cfg['kf_h'])  # Shorts em pé, vídeo longo deitado
    e = torch.load(f"/content/femb/{s['id']}.pt")
    for c in range(s['cands']):
        out = f"{OUT}/keyframes/{s['id']}_{c}.png"
        if os.path.exists(out):
            continue
        t0 = time.time()
        gen = torch.Generator('cpu').manual_seed(s.get('seed', 1) * 100 + c)
        with torch.inference_mode():
            lat = pipe(prompt_embeds=e['pe'].to('cuda', dt), pooled_prompt_embeds=e['pooled'].to('cuda', dt),
                       width=kw, height=kh, num_inference_steps=cfg.get('kf_steps', 4), guidance_scale=0.0,
                       generator=gen, output_type='latent').images
            if not torch.isfinite(lat).all():
                print(f"{s['id']}_{c} NaN", flush=True); continue
            lat = pipe._unpack_latents(lat, kh, kw, pipe.vae_scale_factor)
            lat = lat.float() / pipe.vae.config.scaling_factor + pipe.vae.config.shift_factor
            img = pipe.image_processor.postprocess(pipe.vae.decode(lat, return_dict=False)[0], output_type='pil')[0]
        img.save(out)
        print(f"[flux] {s['id']}_{c} ok {time.time() - t0:.0f}s", flush=True)
'''

ENCODER = TXT_LOADER + r'''
import os, sys, json
from transformers import AutoTokenizer, UMT5EncoderModel
path = sys.argv[1]
shots = [s for s in json.load(open(os.environ['LKS_IN'] + '/shots.json', encoding='utf-8')) if s.get('picks')]
os.makedirs('/content/emb', exist_ok=True)
tok = AutoTokenizer.from_pretrained(path, subfolder='tokenizer')
te = load_txt(UMT5EncoderModel, path, 'text_encoder')
with torch.no_grad():
    for s in shots:
        t = tok([s['prompt']], padding='max_length', max_length=512, truncation=True,
                add_special_tokens=True, return_attention_mask=True, return_tensors='pt')
        ids, mask = t.input_ids.to('cuda'), t.attention_mask.to('cuda')
        seq = int(mask.sum())
        h = te(ids, mask).last_hidden_state.float()[:, :seq]
        assert torch.isfinite(h).all(), 'UMT5 gerou NaN'
        h = torch.cat([h, h.new_zeros(1, 512 - seq, h.shape[-1])], dim=1)
        torch.save(h.cpu(), f"/content/emb/{s['id']}.pt")
print('wan encode ok', len(shots), flush=True)
'''

I2V = r'''
import os, sys, json, time, torch
from PIL import Image
from diffusers import WanImageToVideoPipeline, WanTransformer3DModel, FlowMatchEulerDiscreteScheduler
from diffusers.schedulers.scheduling_flow_match_euler_discrete import FlowMatchEulerDiscreteSchedulerOutput
from diffusers.utils import export_to_video
path = sys.argv[1]
OUT = os.environ['LKS_OUT']
cfg = json.load(open(os.environ['LKS_IN'] + '/cfg.json'))
shots = json.load(open(os.environ['LKS_IN'] + '/shots.json', encoding='utf-8'))
jobs = [(s, p) for s in shots for p in s.get('picks', [])]
SIG = [1.0, 0.757, 0.522]
class DMD(FlowMatchEulerDiscreteScheduler):
    def set_timesteps(self, num_inference_steps=None, device=None, **kw):
        s = torch.tensor(SIG + [0.0], dtype=torch.float32, device=device)
        self.sigmas = s; self.timesteps = s[:-1] * 1000; self.num_inference_steps = len(SIG)
        self._step_index = None; self._begin_index = None
    def step(self, model_output, timestep, sample, generator=None, return_dict=True, **kw):
        if self._step_index is None: self._init_step_index(timestep)
        i = self._step_index; sg, sn = self.sigmas[i], self.sigmas[i + 1]
        x0 = sample.float() - sg * model_output.float()
        prev = (1 - sn) * x0 + sn * torch.randn_like(x0) if sn > 0 else x0
        self._step_index += 1; prev = prev.to(model_output.dtype)
        return (prev,) if not return_dict else FlowMatchEulerDiscreteSchedulerOutput(prev_sample=prev)
def cover(im, w, h):
    sw, sh = im.size; r = max(w / sw, h / sh)
    im = im.resize((round(sw * r), round(sh * r)), Image.LANCZOS)
    x, y = (im.width - w) // 2, (im.height - h) // 2
    return im.crop((x, y, x + w, y + h))
# transformer direto na GPU (a RAM do Colab grátis não aguenta 10 GB) e depois pesos em fp8
tr = WanTransformer3DModel.from_pretrained(path, subfolder='transformer', torch_dtype=torch.float16, device_map={'': 0})
tr.enable_layerwise_casting(storage_dtype=torch.float8_e4m3fn, compute_dtype=torch.float16)
torch.cuda.empty_cache()
pipe = WanImageToVideoPipeline.from_pretrained(path, transformer=tr, text_encoder=None, tokenizer=None,
                                               torch_dtype=torch.float16)
pipe.scheduler = DMD.from_config(pipe.scheduler.config)
pipe.vae.to('cuda', dtype=torch.float16); pipe.vae.enable_tiling(); pipe.vae.enable_slicing()
print('i2v pronto: expand_timesteps =', pipe.config.expand_timesteps, len(jobs), 'clipes,',
      f'{torch.cuda.memory_allocated() / 2**30:.1f} GiB na GPU', flush=True)
for s, p in jobs:
    out = f"{OUT}/clips/{s['id']}_{p}.mp4"
    kf = f"{OUT}/keyframes/{s['id']}_{p}.png"
    if os.path.exists(out) or not os.path.exists(kf):
        continue
    w, h = s.get('w', cfg['w']), s.get('h', cfg['h'])
    img = cover(Image.open(kf).convert('RGB'), w, h)
    pe = torch.load(f"/content/emb/{s['id']}.pt").to('cuda', torch.float16)
    t0 = time.time()
    try:
        gen = torch.Generator('cuda').manual_seed(s.get('seed', 1))
        with torch.inference_mode():
            fr = pipe(image=img, prompt_embeds=pe, guidance_scale=1.0, num_inference_steps=3, generator=gen,
                      height=h, width=w, num_frames=s.get('frames', cfg['frames'])).frames[0]
        fr = fr[cfg.get('skip', 6):]  # os primeiros quadros saltam da imagem-chave para o vídeo: cortar
        export_to_video(fr, out + '.tmp.mp4', fps=24)
        os.replace(out + '.tmp.mp4', out)
        print(f"[i2v] {s['id']}_{p} ok {time.time() - t0:.0f}s ({len(fr)} quadros)", flush=True)
    except Exception as e:
        import traceback; traceback.print_exc()
        print(f"[i2v] {s['id']}_{p} ERRO {e!r}"[:300], flush=True); torch.cuda.empty_cache()
'''

UPSCALE = r'''
import os, re, sys, json, glob, time, subprocess, urllib.request, numpy as np, torch, imageio_ffmpeg
from spandrel import ModelLoader
OUT = os.environ['LKS_OUT']
cfg = json.load(open(os.environ['LKS_IN'] + '/cfg.json'))
FF = imageio_ffmpeg.get_ffmpeg_exe()
mp = '/content/realesr-general-x4v3.pth'
if not os.path.exists(mp):
    urllib.request.urlretrieve('https://github.com/xinntao/Real-ESRGAN/releases/download/v0.2.5.0/realesr-general-x4v3.pth', mp)
net = ModelLoader().load_from_file(mp).model.cuda().eval().half()
OW, OH = cfg['out_w'], cfg['out_h']
for clip in sorted(glob.glob(f'{OUT}/clips/*.mp4')):
    out = clip.replace('/clips/', '/final/')
    if os.path.exists(out) or clip.endswith('.tmp.mp4'):
        continue
    t0 = time.time()
    info = subprocess.run([FF, '-i', clip], capture_output=True, text=True).stderr
    w, h = map(int, re.search(r', (\d{3,4})x(\d{3,4})', info).groups())
    rd = subprocess.Popen([FF, '-loglevel', 'error', '-i', clip, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'],
                          stdout=subprocess.PIPE)
    wr = subprocess.Popen([FF, '-y', '-loglevel', 'error', '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-s', f'{OW}x{OH}',
                           '-r', '24', '-i', '-', '-c:v', 'libx264', '-crf', str(cfg.get('crf', 17)), '-preset', 'slow',
                           '-pix_fmt', 'yuv420p', out + '.tmp.mp4'], stdin=subprocess.PIPE)
    n = 0
    with torch.inference_mode():
        while True:
            buf = rd.stdout.read(w * h * 3)
            if len(buf) < w * h * 3:
                break
            x = torch.from_numpy(np.frombuffer(buf, np.uint8).reshape(h, w, 3).copy()).cuda()
            x = x.permute(2, 0, 1)[None].half() / 255
            y = torch.nn.functional.interpolate(net(x).float(), size=(OH, OW), mode='bicubic', antialias=True, align_corners=False)
            mix = cfg.get('up_mix', 0.75)  # só o ESRGAN fica com cara de desenho: mistura com a ampliação simples
            if mix < 1:
                y = mix * y + (1 - mix) * torch.nn.functional.interpolate(x.float(), size=(OH, OW), mode='bicubic', align_corners=False)
            y = (y.clamp(0, 1)[0].permute(1, 2, 0) * 255).round().byte().cpu().numpy()
            wr.stdin.write(y.tobytes()); n += 1
    wr.stdin.close(); wr.wait(); rd.wait()
    os.replace(out + '.tmp.mp4', out)
    print(f'[up] {os.path.basename(clip)} {n} quadros {time.time() - t0:.0f}s', flush=True)
'''


def stage(name, *args):
    p = f'/content/lks_{name.lower()}.py'
    open(p, 'w', encoding='utf-8').write(globals()[name])
    r = subprocess.run([sys.executable, p, *args])
    log(name, 'terminou' if r.returncode == 0 else f'FALHOU (código {r.returncode})')
    return r.returncode == 0


def main():
    from huggingface_hub import snapshot_download, hf_hub_download
    from PIL import Image
    log(len(SHOTS), 'cenas', {k: v for k, v in CFG.items() if k != 'kf_map'})
    # imagens-chave aprovadas que vieram no lote
    for f in glob.glob(f'{IN}/keyframes/*'):
        dst = f"{OUT}/keyframes/{os.path.splitext(os.path.basename(f))[0]}.png"
        if not os.path.exists(dst):
            Image.open(f).convert('RGB').save(dst)
    if any(s.get('cands') for s in SHOTS):
        fp = snapshot_download('unsloth/FLUX.1-schnell', allow_patterns=[
            'model_index.json', 'scheduler/*', 'text_encoder/*', 'text_encoder_2/*', 'tokenizer/*', 'tokenizer_2/*',
            'transformer/config.json', 'vae/*'])
        gg = hf_hub_download('city96/FLUX.1-schnell-gguf', 'flux1-schnell-Q6_K.gguf')
        log('FLUX baixado')
        if stage('FLUX_ENC', fp):
            stage('FLUX', fp, gg)
        shutil.rmtree('/content/hf/hub/models--unsloth--FLUX.1-schnell', ignore_errors=True)
        shutil.rmtree('/content/hf/hub/models--city96--FLUX.1-schnell-gguf', ignore_errors=True)
    if any(s.get('picks') for s in SHOTS):
        wp = snapshot_download('FastVideo/FastWan2.2-TI2V-5B-FullAttn-Diffusers')
        log('FastWan baixado')
        if stage('ENCODER', wp):
            stage('I2V', wp)
        stage('UPSCALE')
    log('PRONTO:', len(glob.glob(f'{OUT}/keyframes/*.png')), 'imagens,', len(glob.glob(f'{OUT}/final/*.mp4')), 'vídeos finais')


main()
